$('document').ready(function(){
console.log("Hello World!");
$('h1').click(function(){console.log("Item clicked!");})
$('.slidedown p').hide();

// In-browser functions
$('#header').click(function() {
    $(this).html('<h1>Ouch!</h1>');
})

$('.image').click(function() {
    $('img').attr("src","./img/profile_picture.png");
})

$(".submit").click(function() {
    var value = $('input#quest').val();
    $('p.answer').text("Your response is " + value + "!")
})

$('.slideup button').click(function() {
    $('.slideup p').slideUp();
})

$('.slidedown button').click(function() {
    $('.slidedown p').slideDown();
})

$('.slidetoggle button').click(function() {
    $('.slidetoggle p').slideToggle();
})

var count = 0;

$('.append button').click(function() {
    if (count < 4) {
        count += 1;
    }
    else {
        $('.append button').text("Please stop");
    }
    $('.append').append("<p>This button adds content!</p>");
})

})

